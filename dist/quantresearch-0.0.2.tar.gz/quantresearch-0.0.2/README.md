# QuantResearch

A comprehensive Python library for quantitative financial analysis and technical indicator calculation. QuantResearch provides easy-to-use functions for fetching market data, calculating technical indicators, and visualizing trading signals.

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Features](#features)
- [API Reference](#api-reference)
  - [Data Fetching](#data-fetching)
  - [Technical Indicators](#technical-indicators)
  - [Visualization](#visualization)
- [Examples](#examples)
- [Requirements](#requirements)
- [License](#license)

## Installation

Install QuantResearch using pip:

```bash
pip install QuantResearch
```

## Quick Start

Here's a simple example to get started:

```python
from QuantResearch import indicators, visualize
import pandas as pd

# Fetch stock data
ticker = "AAPL"
data = indicators.fetch_data(ticker, start_date="2023-01-01", end_date="2024-01-01")

# Calculate RSI
rsi = indicators.Rsi(data['Close'], period=14)

# Plot RSI
visualize.plot_rsi(rsi, period=14, ticker=ticker)
```

## Features

QuantResearch includes a comprehensive suite of tools for quantitative analysis:

- **Data Fetching**: Download historical OHLCV data from Yahoo Finance
- **Technical Indicators**: RSI, MACD, Bollinger Bands, ATR, SMA, EMA, DEMA, TEMA, RVWAP
- **Visualization**: Professional charts for price action, indicators, and trading signals
- **Signal Generation**: Identify buy/sell crossover points automatically

## API Reference

### Data Fetching

#### `fetch_data(ticker, start_date, end_date)`

Downloads historical OHLCV (Open, High, Low, Close, Volume) data for a given ticker.

**Parameters:**
- `ticker` (str): Stock ticker symbol (e.g., "AAPL", "MSFT")
- `start_date` (str): Start date in format "YYYY-MM-DD"
- `end_date` (str): End date in format "YYYY-MM-DD"

**Returns:**
- pandas.DataFrame: Contains columns for Open, High, Low, Close, Adj Close, Volume

**Example:**
```python
data = indicators.fetch_data("AAPL", "2023-01-01", "2024-01-01")
print(data.head())
```

---

### Technical Indicators

#### `Rsi(price, period=14)`

Calculates the Relative Strength Index (RSI), a momentum oscillator measuring the magnitude of recent price changes.

**Parameters:**
- `price` (pandas.Series): Price series (typically closing prices)
- `period` (int): Lookback period, default is 14

**Returns:**
- pandas.Series: RSI values (0-100)

**Interpretation:**
- RSI > 70: Potentially overbought
- RSI < 30: Potentially oversold
- RSI 30-70: Neutral zone

**Example:**
```python
rsi = indicators.Rsi(data['Close'], period=14)
```

---

#### `bb_bands(price, period=20, num_std=2)`

Calculates Bollinger Bands, consisting of a moving average and upper/lower bands based on standard deviation.

**Parameters:**
- `price` (pandas.Series): Price series (typically closing prices)
- `period` (int): Lookback period, default is 20
- `num_std` (int or float): Number of standard deviations, default is 2

**Returns:**
- Tuple of three pandas.Series: (upper_band, middle_band, lower_band)

**Interpretation:**
- Price near upper band: Potentially overbought
- Price near lower band: Potentially oversold
- Bands widen during volatility, contract during calm periods

**Example:**
```python
upper, mid, lower = indicators.bb_bands(data['Close'], period=20, num_std=2)
```

---

#### `macd(price, short_period=12, long_period=26, signal_period=9)`

Calculates MACD (Moving Average Convergence Divergence), a trend-following momentum indicator.

**Parameters:**
- `price` (pandas.Series): Price series
- `short_period` (int): Short EMA period, default is 12
- `long_period` (int): Long EMA period, default is 26
- `signal_period` (int): Signal line EMA period, default is 9

**Returns:**
- Tuple of three pandas.Series: (macd_line, signal_line, histogram)

**Interpretation:**
- MACD crosses above signal line: Bullish signal
- MACD crosses below signal line: Bearish signal
- Histogram divergence: Potential trend reversal

**Example:**
```python
macd_line, signal_line, histogram = indicators.macd(data['Close'])
```

---

#### `atr(data, period=14)`

Calculates Average True Range (ATR), a volatility indicator measuring the average price movement range.

**Parameters:**
- `data` (pandas.DataFrame): OHLC data with 'High', 'Low', 'Close' columns
- `period` (int): Lookback period, default is 14

**Returns:**
- pandas.Series: ATR values

**Interpretation:**
- Higher ATR: Higher volatility
- Lower ATR: Lower volatility
- Useful for setting stop-loss and take-profit levels

**Example:**
```python
atr_values = indicators.atr(data, period=14)
```

---

#### `sma(price, period=9)`

Calculates Simple Moving Average (SMA), the average price over a specified period.

**Parameters:**
- `price` (pandas.Series): Price series
- `period` (int): Lookback period, default is 9

**Returns:**
- pandas.Series: SMA values

**Example:**
```python
sma_9 = indicators.sma(data['Close'], period=9)
sma_20 = indicators.sma(data['Close'], period=20)
```

---

#### `ema(price, period=9)`

Calculates Exponential Moving Average (EMA), which gives more weight to recent prices.

**Parameters:**
- `price` (pandas.Series): Price series
- `period` (int): Lookback period, default is 9

**Returns:**
- pandas.Series: EMA values

**Example:**
```python
ema_9 = indicators.ema(data['Close'], period=9)
```

---

#### `demma(price, period=9)`

Calculates Double Exponential Moving Average (DEMA), a smoother trend indicator that reduces lag.

**Parameters:**
- `price` (pandas.Series): Price series
- `period` (int): Lookback period, default is 9

**Returns:**
- pandas.Series: DEMA values

**Example:**
```python
dema_9 = indicators.demma(data['Close'], period=9)
```

---

#### `temma(price, period=9)`

Calculates Triple Exponential Moving Average (TEMA), providing even smoother trend tracking with minimal lag.

**Parameters:**
- `price` (pandas.Series): Price series
- `period` (int): Lookback period, default is 9

**Returns:**
- pandas.Series: TEMA values

**Example:**
```python
tema_9 = indicators.temma(data['Close'], period=9)
```

---

#### `RVWAP(high, low, close, volume, period=20)`

Calculates Volume-Weighted Average Price (VWAP), a trading benchmark that reflects both price and volume.

**Parameters:**
- `high` (pandas.Series): High prices
- `low` (pandas.Series): Low prices
- `close` (pandas.Series): Close prices
- `volume` (pandas.Series): Trading volume
- `period` (int): Lookback period, default is 20

**Returns:**
- pandas.Series: VWAP values

**Interpretation:**
- Price above VWAP: Bullish bias
- Price below VWAP: Bearish bias

**Example:**
```python
vwap = indicators.RVWAP(data['High'], data['Low'], data['Close'], data['Volume'], period=20)
```

---

### Visualization

#### `show_macd(macdline, signalLine, hist, ticker)`

Displays MACD, signal line, and histogram.

**Parameters:**
- `macdline` (pandas.Series): MACD line values
- `signalLine` (pandas.Series): Signal line values
- `hist` (pandas.Series): Histogram values
- `ticker` (str): Stock ticker for title

**Example:**
```python
visualize.show_macd(macd_line, signal_line, histogram, "AAPL")
```

---

#### `plot_bollinger(ajd_close, bb_upper, bb_mid, bb_lower, ticker=None)`

Visualizes Bollinger Bands with price action.

**Parameters:**
- `ajd_close` (pandas.Series): Adjusted close prices
- `bb_upper` (pandas.Series): Upper Bollinger Band
- `bb_mid` (pandas.Series): Middle Bollinger Band
- `bb_lower` (pandas.Series): Lower Bollinger Band
- `ticker` (str, optional): Stock ticker for title

**Example:**
```python
upper, mid, lower = indicators.bb_bands(data['Close'])
visualize.plot_bollinger(data['Adj Close'], upper, mid, lower, ticker="AAPL")
```

---

#### `plot_rsi(rsi, period=14, lower=30, upper=70, ticker=None)`

Displays RSI with overbought/oversold levels.

**Parameters:**
- `rsi` (pandas.Series): RSI values
- `period` (int): RSI period for labeling, default is 14
- `lower` (int): Oversold threshold, default is 30
- `upper` (int): Overbought threshold, default is 70
- `ticker` (str, optional): Stock ticker for title

**Example:**
```python
rsi = indicators.Rsi(data['Close'])
visualize.plot_rsi(rsi, period=14, ticker="AAPL")
```

---

#### `plot_moving_averages(price, sma_val, ema_val, dema_val, tema_val, title="Moving Averages Comparison")`

Compares multiple moving average types on the same chart.

**Parameters:**
- `price` (pandas.Series): Price series
- `sma_val` (pandas.Series): Simple Moving Average
- `ema_val` (pandas.Series): Exponential Moving Average
- `dema_val` (pandas.Series): Double Exponential Moving Average
- `tema_val` (pandas.Series): Triple Exponential Moving Average
- `title` (str, optional): Chart title

**Example:**
```python
sma = indicators.sma(data['Close'], period=9)
ema = indicators.ema(data['Close'], period=9)
dema = indicators.demma(data['Close'], period=9)
tema = indicators.temma(data['Close'], period=9)

visualize.plot_moving_averages(data['Close'], sma, ema, dema, tema, title="AAPL Moving Averages")
```

---

#### `plot_crossovers(price, ma1, ma2, ma1_label='MA1', ma2_label='MA2')`

Visualizes moving average crossovers with automatic buy/sell signal detection.

**Parameters:**
- `price` (pandas.Series): Price series
- `ma1` (pandas.Series): First moving average
- `ma2` (pandas.Series): Second moving average
- `ma1_label` (str): Label for first MA, default is 'MA1'
- `ma2_label` (str): Label for second MA, default is 'MA2'

**Returns:**
- Displays chart with green triangles (buy signals) and red triangles (sell signals)

**Example:**
```python
sma_fast = indicators.sma(data['Close'], period=9)
sma_slow = indicators.sma(data['Close'], period=21)

visualize.plot_crossovers(data['Close'], sma_fast, sma_slow, 
                         ma1_label='SMA 9', ma2_label='SMA 21')
```

---

## Examples

### Example 1: Complete Technical Analysis

```python
from QuantResearch import indicators, visualize

# Fetch data
data = indicators.fetch_data("AAPL", "2023-01-01", "2024-01-01")

# Calculate indicators
rsi = indicators.Rsi(data['Close'], period=14)
macd_line, signal_line, histogram = indicators.macd(data['Close'])
upper, mid, lower = indicators.bb_bands(data['Close'])
sma_9 = indicators.sma(data['Close'], period=9)
sma_21 = indicators.sma(data['Close'], period=21)

# Visualize
visualize.plot_rsi(rsi, ticker="AAPL")
visualize.show_macd(macd_line, signal_line, histogram, "AAPL")
visualize.plot_bollinger(data['Adj Close'], upper, mid, lower, ticker="AAPL")
visualize.plot_crossovers(data['Close'], sma_9, sma_21, "SMA 9", "SMA 21")
```

### Example 2: Moving Average Strategy

```python
from QuantResearch import indicators, visualize

data = indicators.fetch_data("MSFT", "2023-06-01", "2024-06-01")

# Compare different moving averages
sma = indicators.sma(data['Close'], period=20)
ema = indicators.ema(data['Close'], period=20)
dema = indicators.demma(data['Close'], period=20)
tema = indicators.temma(data['Close'], period=20)

visualize.plot_moving_averages(data['Close'], sma, ema, dema, tema, 
                               title="MSFT Moving Averages Comparison")
```

### Example 3: Volatility Analysis

```python
from QuantResearch import indicators

data = indicators.fetch_data("TSLA", "2024-01-01", "2024-11-01")

# Calculate volatility metrics
atr_values = indicators.atr(data, period=14)
upper, mid, lower = indicators.bb_bands(data['Close'], period=20, num_std=2)

print("ATR (Last 10 days):")
print(atr_values.tail(10))
```

---

## Requirements

QuantResearch requires the following dependencies:

- Python >= 3.7
- pandas >= 1.0.0
- yfinance >= 0.1.68
- matplotlib >= 3.0.0

These will be installed automatically when you install QuantResearch via pip.

---

## License

QuantResearch is released under the MIT License. See LICENSE file for details.

---

## Support & Contributing

For issues, feature requests, or contributions, please visit the project repository.

For bug reports or questions, please contact the development team.

---

## Disclaimer

QuantResearch is provided for educational and research purposes only. It is not intended as financial advice. Always consult with a financial advisor before making investment decisions. Past performance is not indicative of future results.

---

## Changelog

### Version 1.0.0
- Initial release
- Core technical indicators (RSI, MACD, Bollinger Bands, ATR, SMA, EMA, DEMA, TEMA, VWAP)
- Visualization functions for all indicators
- Data fetching from Yahoo Finance